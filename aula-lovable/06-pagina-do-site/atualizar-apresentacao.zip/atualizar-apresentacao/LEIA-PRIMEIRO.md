# Atualizar a apresentação da página /paginas-com-ia

Substitua a pasta da apresentação no site por esta versão nova.

1. Troque todo o conteúdo de `/materiais/paginas-com-ia/apresentacao/` pela pasta `apresentacao/` deste zip (`index.html`, `assets/` e `lp/`).
2. Não altere nada dentro dos arquivos: sirva como estão, sem build e sem otimização.
3. Não mude a página `/paginas-com-ia` nem os arquivos de `/materiais/paginas-com-ia/downloads/`.

O que mudou nesta versão:
- um slide extra novo sobre a integração com o RD Station;
- um botão "Slides (G)" que abre uma grade com todos os slides.

Depois de publicar, confira:
- a apresentação abre no iframe da página;
- o botão "Slides (G)" abre a grade, e clicar numa miniatura leva ao slide;
- o slide 34 é o do RD Station;
- clicar no print de uma LP continua abrindo a página em tela cheia;
- se o navegador mostrar a versão antiga, force a atualização (Ctrl+Shift+R) ou limpe o cache da hospedagem.
